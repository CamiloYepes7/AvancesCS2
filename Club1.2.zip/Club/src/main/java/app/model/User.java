/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.model;

/**
 *
 * @author ESTUDIANTES
 */
public class User {
    private String UserName;
    private String Password;
    private String Role;
    private Person PersonId;

    public User() {
    
    }

    public String getUserName() {
        return UserName;
    }

    public String getPassword() {
        return Password;
    }

    public String getRole() {
        return Role;
    }

    public Person getPersonId() {
        return PersonId;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public void setRole(String Role) {
        this.Role = Role;
    }

    public void setPersonId(Person PersonId) {
        this.PersonId = PersonId;
    }
}