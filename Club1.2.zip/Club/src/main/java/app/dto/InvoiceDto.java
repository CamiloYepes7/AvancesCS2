
package app.dto;

import app.model.Partner;
import app.model.Person;
import java.util.Date;


public class InvoiceDto {
       private long id;
    private PersonDto PersonId;
    private PartnerDto PartnerId;
    private Date CreationDate;
    private double Amount;
    private boolean Status;

    public InvoiceDto() {
    }

    public long getId() {
        return id;
    }

    public PersonDto getPersonId() {
        return PersonId;
    }

    public PartnerDto getPartnerId() {
        return PartnerId;
    }

    public Date getCreationDate() {
        return CreationDate;
    }

    public double getAmount() {
        return Amount;
    }

    public boolean isStatus() {
        return Status;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setPersonId(PersonDto PersonId) {
        this.PersonId = PersonId;
    }

    public void setPartnerId(PartnerDto PartnerId) {
        this.PartnerId = PartnerId;
    }

    public void setCreationDate(Date CreationDate) {
        this.CreationDate = CreationDate;
    }

    public void setAmount(double Amount) {
        this.Amount = Amount;
    }

    public void setStatus(boolean Status) {
        this.Status = Status;
    }
    
}

