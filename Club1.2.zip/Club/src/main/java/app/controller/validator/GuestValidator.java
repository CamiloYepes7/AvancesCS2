
package app.controller.validator;

public class GuestValidator extends CommonsValidator{

    public GuestValidator() {
        super();
    }
      
        public long validId(String Id) throws Exception{
		return super.isValidLong("el id del invitado ", Id);
}

    public Object getReader() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
         }

