
package app.model;

import java.util.Date;


public class Invoice {
    private long id;
    private Person PersonId;
    private Partner PartnerId;
    private Date CreationDate;
    private double Amount;
    private boolean Status;

    public Invoice() {
    
    }

    public long getId() {
        return id;
    }

    public Person getPersonId() {
        return PersonId;
    }

    public Partner getPartnerId() {
        return PartnerId;
    }

    public Date getCreationDate() {
        return CreationDate;
    }

    public double getAmount() {
        return Amount;
    }

    public boolean isStatus() {
        return Status;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setPersonId(Person PersonId) {
        this.PersonId = PersonId;
    }

    public void setPartnerId(Partner PartnerId) {
        this.PartnerId = PartnerId;
    }

    public void setCreationDate(Date CreationDate) {
        this.CreationDate = CreationDate;
    }

    public void setAmount(double Amount) {
        this.Amount = Amount;
    }

    public void setStatus(boolean Status) {
        this.Status = Status;
    }

}
