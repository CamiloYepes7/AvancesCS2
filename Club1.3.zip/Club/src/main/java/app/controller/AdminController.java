/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controller;

import app.controller.validator.InvoiceValidator;
import app.controller.validator.PartnerValidator;
import app.controller.validator.PersonValidator;
import app.controller.validator.UserValidator;

/**
 *
 * @author camil
 */
public class AdminController implements ControllerInterface {
    private PersonValidator personValidator;
	private UserValidator userValidator;
        private PartnerValidator PartnerValidator;
        private InvoiceValidator InvoiceValidator;
         private static final String MENU = "    private static final String MENU = \"ingrese la opcion que desea ejecutar: \\n 1. crear socio  \\n 2.ver historial de facturas \\n 3.ver historial facturas de socio \\n 4.ver historial facturas de invitado \\n 5.ejecutar promocion VIP \\n 6. cerrar sesion"  + "" ;
        
	@Override
	public void session() throws Exception {
		boolean session = true;
		while (session) {
			session = menu();
		}
        }
private boolean menu() {
		try {
			System.out.println(MENU);
			String option = Utils.getReader().nextLine();
			return options(option);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return true;
		}
	}

	private boolean options(String option) throws Exception {
		switch (option) {
		case "1": {
			this.CreatePartner();
			return true;
		}
		case "2": {
			this.ClubInvoices();
			return true;
		}
		case "3": {
			this.PartnerInvoices();
			return true;
		}
		case "4": {
			this.GuestInvoices();
			return true;
		}
                case "5": {
			this.VipPromotion();
			return true;
                }
           
		case "6": {
			System.out.println("Se ha cerrado sesion");
			return false;
		}
		default: {
			System.out.println("ingrese una opcion valida");
			return true;
		}
		}
	}

	private void CreatePartner() throws Exception {
	}

        private void ClubInvoices() throws Exception {
	}
        
        private void PartnerInvoices() throws Exception {
	}
        
        private void GuestInvoices() throws Exception {
        }
            private void VipPromotion() throws Exception {
	}
	
            PartnerDto PartnerDto = new PartnerDto
                    PartnerDto.setId(id);
                    
                    
                    
        

}

	