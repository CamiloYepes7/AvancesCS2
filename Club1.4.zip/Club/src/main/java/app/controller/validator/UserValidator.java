
package app.controller.validator;

public class UserValidator extends CommonsValidator{
    
    public UserValidator() {
		super();
	}
	
	public void validUserName(String UserName) throws Exception {
		super.isValidString("el nombre de usuario ", UserName);
	}
	public void validPassword(String Password) throws Exception {
		super.isValidString("la contraseña de usuario ", Password);
	}
	public void validRole(String Role) throws Exception {
		super.isValidString("el rol de usuario ", Role);
	}

}
