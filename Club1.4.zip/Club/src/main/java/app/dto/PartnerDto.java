
package app.dto;

import app.model.User;
import java.util.Date;


public class PartnerDto {
    private long Id;
    private UserDto UserId;
    private double Amount;
    private boolean Type;
    private Date CreationDate;

    public PartnerDto() {
    }

    public long getId() {
        return Id;
    }

    public UserDto getUserId() {
        return UserId;
    }

    public double getAmount() {
        return Amount;
    }

    public boolean isType() {
        return Type;
    }

    public Date getCreationDate() {
        return CreationDate;
    }

    public void setId(long Id) {
        this.Id = Id;
    }

    public void setUserId(UserDto UserId) {
        this.UserId = UserId;
    }

    public void setAmount(double Amount) {
        this.Amount = Amount;
    }

    public void setType(boolean Type) {
        this.Type = Type;
    }

    public void setCreationDate(Date CreationDate) {
        this.CreationDate = CreationDate;
    }
    
}
