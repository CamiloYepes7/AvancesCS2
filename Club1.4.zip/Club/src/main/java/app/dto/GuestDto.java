
package app.dto;

import app.model.Partner;
import app.model.User;

/**
 *
 * @author camil
 */
public class GuestDto {
      private long Id;
    private UserDto UserId;
    private PartnerDto PartnerId;
    private boolean Status;

    public GuestDto() {
    }

    public long getId() {
        return Id;
    }

    public UserDto getUserId() {
        return UserId;
    }

    public PartnerDto getPartnerId() {
        return PartnerId;
    }

    public boolean isStatus() {
        return Status;
    }

    public void setId(long Id) {
        this.Id = Id;
    }

    public void setUserId(UserDto UserId) {
        this.UserId = UserId;
    }

    public void setPartnerId(PartnerDto PartnerId) {
        this.PartnerId = PartnerId;
    }

    public void setStatus(boolean Status) {
        this.Status = Status;
    }
    
}
