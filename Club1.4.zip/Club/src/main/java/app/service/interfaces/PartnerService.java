/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package app.service.interfaces;

import app.dto.PersonDto;
import app.dto.GuestDto;
/**
 *
 * @author ESTUDIANTES
 */
public interface PartnerService {
    
public interface VeterinarianService {
	public void createGuest(GuestDto GuestDto) throws Exception;

}
}
