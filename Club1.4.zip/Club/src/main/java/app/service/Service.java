package app.service;

import app.dao.PersonDaoImplementation;
import app.dao.UserDaoImplementation;
import app.dao.interfaces.PersonDao;
import app.dao.interfaces.UserDao;
import app.dto.UserDto;
import app.service.interfaces.AdminService;
import app.service.interfaces.PartnerService;

public class Service implements LonginService, AdminService, PartnerService;
private UserDao userDao;
	private PersonDao personDao;
	public static UserDto user;

public Service() {
		this.userDao = new UserDaoImplementation();
		this.personDao= new PersonDaoImplementation();

	}
