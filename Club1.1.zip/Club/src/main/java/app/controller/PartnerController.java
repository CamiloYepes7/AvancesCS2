/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controller;

import app.controller.validator.GuestValidator;
import app.controller.validator.PartnerValidator;
import app.controller.validator.PersonValidator;
import app.dto.GuestDto;
import app.dto.PartnerDto;
import static java.awt.SystemColor.MENU;

/**
 *
 * @author camil
 */
public class PartnerController implements ControllerInterface {

    private GuestValidator GuestValidator;
    private static final String MENU = "ingrese la opcion que desea ejecutar: \n 1. para crear invitado. \n 2. activar invitado. \n 3. para desactivar invitado. \n 4. hacer consumo. \n 5. subir fondos. \n 6. solicitar baja. \n 7. solicitar promocion. \n 8. cerrrar sesion." ;
  
    	@Override
	public void session() throws Exception {
		boolean session = true;
		while (session) {
			session = menu();
		}

	}

	private boolean menu() {
		try {
			System.out.println(MENU);
			String option = Utils.getReader().nextLine();
			return options(option);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return true;
		}
	}

	private boolean options(String option) throws Exception {
		switch (option) {
		case "1": {
			this.CreateGuest();
			return true;
		}
		case "2": {
			this.ActivateGuest();
			return true;
		}
		case "3": {
			this.DesactivateGuest();
			return true;
		}
		case "4": {
			this.MakeConsumption();
			return true;
		}
                case "5": {
			this.UploadFunds();
			return true;
                }
                case "6": {
			this.RequestCancelation();
			return true;
                }
                case "7": {
			this.RequestVip();
			return true;
                }
                
		case "8": {
			System.out.println("Se ha cerrado sesion");
			return false;
		}
		default: {
			System.out.println("ingrese una opcion valida");
			return true;
		}
		}
	}

	private void CreateGuest() throws Exception {
	}

        private void ActivateGuest() throws Exception {
	}
        
        private void DesactivateGuest() throws Exception {
	}
        
        private void MakeConsumption() throws Exception {
	}
        
	private void UploadFunds() throws Exception {
            System.out.println("ingrese la cantidad que desea ingresar a sus fondos");
		String Amount = Utils.getReader().nextLine();
		PartnerValidator.isValidDouble(Amount);
	}
        
          private void RequestCancelation() throws Exception {
	}
          
           private void RequestVip() throws Exception {
	}

GuestDto GuestDto = new GuestDto();
GuestDto.GuestId(Id);
}
