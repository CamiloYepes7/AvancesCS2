
package app.controller.validator;

public class PersonValidator extends CommonsValidator {
    public PersonValidator() {
		super();
	}
	
	public void validName(String Name) throws Exception{
		super.isValidString("el nombre de la persona ", Name);
	}
	
	public long validDocument(String Document) throws Exception{
		return super.isValidLong("la cedula de la persona ", Document);
	}
        public  long ValidCelephone(String Celphone) throws Exception{
            return super.isValidLong("la telefono de la persona ", Celphone);
        }
}
