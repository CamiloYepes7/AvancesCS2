
package app.controller.validator;

public class InvoiceValidator extends CommonsValidator{

    public InvoiceValidator() {
        super();
    }
    
    	public double validAmount(String Amount) throws Exception{
		return super.isValidDouble("el monto de la factura ", Amount);
	}
        public void validDescription(String Description)throws Exception {
		super.isValidString("la medicina asignada ", Description);
	}
	

}

