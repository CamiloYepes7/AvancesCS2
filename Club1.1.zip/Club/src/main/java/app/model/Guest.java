
package app.model;


public class Guest {
    private long Id;
    private User UserId;
    private Partner PartnerId;
    private boolean Status;

    public Guest() {
    
    }

    public long getId() {
        return Id;
    }

    public User getUserId() {
        return UserId;
    }

    public Partner getPartnerId() {
        return PartnerId;
    }

    public boolean isStatus() {
        return Status;
    }

    public void setId(long Id) {
        this.Id = Id;
    }

    public void setUserId(User UserId) {
        this.UserId = UserId;
    }

    public void setPartnerId(Partner PartnerId) {
        this.PartnerId = PartnerId;
    }

    public void setStatus(boolean Status) {
        this.Status = Status;
    }

}