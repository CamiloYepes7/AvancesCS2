
package app.dto;


public class PersonDto {
      private long Id;
    private long Document;
    private String Name;
    private long Celphone;

    public PersonDto() {
        
    }

    public long getId() {
        return Id;
    }

    public long getDocument() {
        return Document;
    }

    public String getName() {
        return Name;
    }

    public long getCelphone() {
        return Celphone;
    }

    public void setId(long Id) {
        this.Id = Id;
    }

    public void setDocument(long Document) {
        this.Document = Document;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setCelphone(long Celphone) {
        this.Celphone = Celphone;
    }

}