package app.controller;

public interface ControllerInterfaces {
	public void session() throws Exception;

}
