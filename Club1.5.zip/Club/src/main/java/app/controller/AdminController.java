/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controller;

import app.controller.validator.PersonValidator;
import app.controller.validator.UserValidator;

/**
 *
 * @author camil
 */
public class AdminController {
    private PersonValidator personValidator;
	private UserValidator userValidator;
	
}
