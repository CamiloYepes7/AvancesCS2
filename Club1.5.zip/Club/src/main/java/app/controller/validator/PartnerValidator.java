
package app.controller.validator;


public class PartnerValidator extends CommonsValidator{

    public static void isValidDouble(String Amount) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    public PartnerValidator() {
        super();
    }
   
   	public double ValidAmount(String Amount) throws Exception{
		return super.isValidDouble("el monto del socio ", Amount);
        }
        public long validId(String Id) throws Exception{
		return super.isValidLong("el id del socio ", Id);
	}
}