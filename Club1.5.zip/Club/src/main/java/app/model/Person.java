/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.model;

/**
 *
 * @author ESTUDIANTES
 */
public class Person {
    private long Id;
    private long Document;
    private String Name;
    private long Celphone;

    public Person() {
        
    }

    public long getId() {
        return Id;
    }

    public long getDocument() {
        return Document;
    }

    public String getName() {
        return Name;
    }

    public long getCelphone() {
        return Celphone;
    }

    public void setId(long Id) {
        this.Id = Id;
    }

    public void setDocument(long Document) {
        this.Document = Document;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setCelphone(long Celphone) {
        this.Celphone = Celphone;
    }

}