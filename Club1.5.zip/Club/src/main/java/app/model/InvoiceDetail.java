/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.model;

/**
 *
 * @author camil
 */
public class InvoiceDetail {
    private long Id;
    private Invoice InvoiceId;
    private int Item;
    private String Description;
    private double Amount;

    public InvoiceDetail() {
      
    }

    public long getId() {
        return Id;
    }

    public Invoice getInvoiceId() {
        return InvoiceId;
    }

    public int getItem() {
        return Item;
    }

    public String getDescription() {
        return Description;
    }

    public double getAmount() {
        return Amount;
    }

    public void setId(long Id) {
        this.Id = Id;
    }

    public void setInvoiceId(Invoice InvoiceId) {
        this.InvoiceId = InvoiceId;
    }

    public void setItem(int Item) {
        this.Item = Item;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public void setAmount(double Amount) {
        this.Amount = Amount;
    }

}