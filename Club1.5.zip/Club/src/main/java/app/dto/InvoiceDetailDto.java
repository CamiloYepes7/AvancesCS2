
package app.dto;

import app.model.Invoice;


public class InvoiceDetailDto {
        private long Id;
    private InvoiceDto InvoiceId;
    private int Item;
    private String Description;
    private double Amount;

    public InvoiceDetailDto() {
    }

    public long getId() {
        return Id;
    }

    public InvoiceDto getInvoiceId() {
        return InvoiceId;
    }

    public int getItem() {
        return Item;
    }

    public String getDescription() {
        return Description;
    }

    public double getAmount() {
        return Amount;
    }

    public void setId(long Id) {
        this.Id = Id;
    }

    public void setInvoiceId(InvoiceDto InvoiceId) {
        this.InvoiceId = InvoiceId;
    }

    public void setItem(int Item) {
        this.Item = Item;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public void setAmount(double Amount) {
        this.Amount = Amount;
    }
    
}
